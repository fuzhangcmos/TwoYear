package com.example.twoyears.test;

import com.example.twoyears.utils.Http_utils;

import android.test.AndroidTestCase;
import android.util.Log;

public class test_http_utils extends AndroidTestCase {
	
	public void sendInfo(){
		String res=Http_utils.doGet("���ҽ���Ц��");
		Log.e("TAG", res);
		System.out.println(res);
		String res1=Http_utils.doGet("�����人�������Ļ�");
		Log.e("TAG", res1);
		System.out.println(res1);
	}

}
