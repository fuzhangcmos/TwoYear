package com.example.twoyears;

import android.app.Activity;
import android.os.Bundle;

import java.util.List;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
public class Activity_three extends Activity {
	
	private Button sensorButton;
	private TextView sensorText;
	private TextView light_sensor,temp_sensor,xx_sendor,xxx_sensor;
	private SensorManager sensorManager;
	private SensorManager sensorManager2;
	private SensorManager sensorManager3;
	private SensorManager sensorManager4;
	private String sensors_name = "";
	private boolean flag_1=true;
	
	private float acc_max_x=0,acc_max_y=0,acc_max_z=0;
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_three);
        
		sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		sensorManager2 = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		sensorManager3 = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		sensorManager4 = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		
		sensorButton = (Button) findViewById(R.id.button_01);
		sensorText = (TextView) findViewById(R.id.text_01);
		light_sensor= (TextView) findViewById(R.id.text_02);
		temp_sensor= (TextView) findViewById(R.id.text_03);
		xx_sendor= (TextView) findViewById(R.id.text_04);
		xxx_sensor= (TextView) findViewById(R.id.text_05);
		
		Sensor lightSensor= sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
		Sensor tempSensor= sensorManager2.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
		Sensor AcceSensor= sensorManager3.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
		Sensor OriSensor= sensorManager4.getDefaultSensor(Sensor.TYPE_ORIENTATION);
		
		sensorManager.registerListener(new SensorEventListener() {
			@Override
			public void onSensorChanged(SensorEvent event) {
				// TODO Auto-generated method stub
				float lux =event.values[0];
				light_sensor.setText("���ߴ�����  "+"--->"+lux+" lux");
			}
			@Override
			public void onAccuracyChanged(Sensor sensor, int accuracy) {
				// TODO Auto-generated method stub
			}
		}, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
		
		sensorManager2.registerListener(new SensorEventListener() {
			@Override
			public void onSensorChanged(SensorEvent event) {
				// TODO Auto-generated method stub
				float lux =event.values[0];
				temp_sensor.setText("�¶ȴ�����  "+"--->"+lux+" C");
			}
			@Override
			public void onAccuracyChanged(Sensor sensor, int accuracy) {
				// TODO Auto-generated method stub
			}
		}, tempSensor, SensorManager.SENSOR_DELAY_NORMAL);
		
		
		sensorManager3.registerListener(new SensorEventListener() {
			@Override
			public void onSensorChanged(SensorEvent event) {
				// TODO Auto-generated method stub
				float acc_x=event.values[0];
				float acc_y=event.values[1];
				float acc_z=event.values[2];
				if(acc_x>=acc_max_x){acc_max_x=acc_x;}
				if(acc_y>=acc_max_y){acc_max_y=acc_y;}
				if(acc_z>=acc_max_z){acc_max_z=acc_z;}
				xx_sendor.setText("���ٶȴ�����  "+" x_max->"+acc_max_x+" y_max->"+acc_max_y+" z_max->"+acc_max_z);
			}
			@Override
			public void onAccuracyChanged(Sensor sensor, int accuracy) {
				// TODO Auto-generated method stub
			}
		}, AcceSensor, SensorManager.SENSOR_DELAY_GAME);
		
		sensorManager4.registerListener(new SensorEventListener() {
			@Override
			public void onSensorChanged(SensorEvent event) {
				// TODO Auto-generated method stub
				float acc_x =event.values[0];
				float acc_y=event.values[1];
				float acc_z=event.values[2];
				xxx_sensor.setText("���򴫸���  "+"x->"+acc_x+"��"+"y->"+acc_y+"�� "+"z->"+acc_z+"��");
			}
			@Override
			public void onAccuracyChanged(Sensor sensor, int accuracy) {
				// TODO Auto-generated method stub
			}
		}, OriSensor, SensorManager.SENSOR_DELAY_NORMAL);
		
		sensorButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				List<Sensor> sensors = sensorManager
						.getSensorList(Sensor.TYPE_ALL);
				if (flag_1==true) {
					for (Sensor sensor : sensors) {
						sensors_name += " ���������� --> " + sensor.getName()+"   ";
					}
					sensorText.setText(sensors_name);
					flag_1=false;
				} else {
					sensorText.setText("");
					sensors_name="";
					flag_1=true;
				}
			}
		});
    }

}
