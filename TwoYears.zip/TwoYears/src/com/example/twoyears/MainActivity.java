package com.example.twoyears;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import com.example.twoyears.view.ArcMenu;
import com.example.twoyears.view.ArcMenu.OnMenuItemClickListener;


public class MainActivity extends Activity {
	   private ArcMenu mArcMenu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        
        mArcMenu = (ArcMenu) findViewById(R.id.id_menu);
        mArcMenu.setOnMenuItemClickListener(new OnMenuItemClickListener()
		{
			@Override
			public void onClick(View view, final int pos)
			{
				//Toast.makeText(MainActivity.this, pos+":"+view.getTag(), Toast.LENGTH_SHORT).show();
				TimerTask task = new TimerTask(){   
				    public void run(){   
						if (pos == 1){
							Intent intent = new Intent();
							intent.setClass(MainActivity.this, Activity_one.class);
							startActivity(intent);
						}else if (pos ==2){
							Intent intent = new Intent();
							intent.setClass(MainActivity.this, Activity_two.class);
							startActivity(intent);
						}else if (pos ==3){
							Intent intent = new Intent();
							intent.setClass(MainActivity.this, Activity_three.class);
							startActivity(intent);
						}else if (pos ==4){
							Intent intent = new Intent();
							intent.setClass(MainActivity.this, Activity_four.class);
							startActivity(intent);
						}else if (pos ==5){
							Intent intent = new Intent();
							intent.setClass(MainActivity.this, Activity_five.class);
							startActivity(intent);
						}
				    }   
				};   
				Timer timer = new Timer();
				timer.schedule(task, 200); 
				
		
			}
		});
     
    }
}
