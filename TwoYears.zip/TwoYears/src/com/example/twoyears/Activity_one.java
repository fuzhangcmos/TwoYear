package com.example.twoyears;

import java.util.HashMap;

import android.app.Activity;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.TextView;

public class Activity_one extends Activity {
	
	 private TextView promise;
	 private SoundPool soundpool;  
     private HashMap<Integer,Integer> soundmap= new HashMap<Integer, Integer>();   //����һ��HashMap����  
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_one);
        
        soundpool = new SoundPool(5,AudioManager.STREAM_SYSTEM, 0); 
        promise = (TextView) findViewById(R.id.promise);
        promise.setClickable(true);
        promise.setFocusable(true);
        soundmap.put(1, soundpool.load(this, R.raw.promise1, 1));  
        promise.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
			   soundpool.play(soundmap.get(1), 1, 1, 0, 0, 1);  
			}
		});
    }
}
