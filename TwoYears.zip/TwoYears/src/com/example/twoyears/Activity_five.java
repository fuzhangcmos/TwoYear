package com.example.twoyears;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

public class Activity_five extends Activity {
	
	private Button button_taobao,button_jindong;
	private String url = "http://www.taobao.com";
	private String url1 = "http://www.jd.com";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_five);
        
        button_taobao=(Button) findViewById(R.id.button_taobao);
        button_jindong=(Button) findViewById(R.id.button_jindong);
        
        
        button_taobao.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Toast.makeText(Activity_five.this, "��������", Toast.LENGTH_SHORT).show();
		        Uri uri = Uri.parse(url);
		        Intent intent = new Intent(Intent.ACTION_VIEW,uri);
		        startActivity(intent);
				}
			});
        
        
        button_jindong.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Toast.makeText(Activity_five.this, "�Ͻ��ܼ�", Toast.LENGTH_SHORT).show();
		        Uri uri = Uri.parse(url1);
		        Intent intent = new Intent(Intent.ACTION_VIEW,uri);
		        startActivity(intent);
				}
			});

    }

}
